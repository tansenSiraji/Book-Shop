Note: 
- The repository only contain HTML and Tailwind code.
- Each of them are structured in functional component and saved as .js to avoid confusion.