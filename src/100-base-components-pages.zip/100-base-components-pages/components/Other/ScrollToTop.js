export const ScrollToTop = () => {
  return (
    <div>ScrollToTop</div>
  )
}
