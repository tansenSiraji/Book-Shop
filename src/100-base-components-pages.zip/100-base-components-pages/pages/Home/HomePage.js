export const HomePage = () => {
  return (
    <main>
        <div>Home</div>
    </main>
  )
}
