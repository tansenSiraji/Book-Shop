export const CartPage = () => {
  return (
    <main>          
    </main>
  )
}
